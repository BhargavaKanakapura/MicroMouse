/*
* Fully functional Graph datastructure, with A* Traversal Algorithms
*/

export class Graph {
	
	constructor(rootNode) {
		
	}
	
	addNode(connections) {
		
	}
	
	shortestPath(node1, node2) {
		
	}
	
}